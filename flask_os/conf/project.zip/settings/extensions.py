# -*- coding: utf-8 -*-

from ..metrics import init_app as m_init_app


def init_app(app):
    m_init_app(app)
