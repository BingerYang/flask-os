# -*- coding: utf-8 -*-
# @Time     : 2020/7/22 7:31 下午
# @Author   : binger
import functools

from flask_sqlalchemy import BaseQuery, SQLAlchemy

db = SQLAlchemy(session_options={'expire_on_commit': False})
Column = functools.partial(db.Column, nullable=False)
